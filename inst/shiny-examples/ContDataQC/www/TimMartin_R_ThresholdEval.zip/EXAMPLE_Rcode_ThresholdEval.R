# ContDataQC R package
# Threshold Analysis Code
# Tim Martin
# Example by Jen.Stamp@tetratech.com and Erik.Leppo@tetratech.com
# Example Date = 2022-01-18
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Packages ----
source("TimMartin_lakes_qcthresholdanalysis.R")
# Add package if missing
if(!require(writexl)){install.packages("writexl")}  #install if needed
library(writexl)

# Variables ----
SiteID <- "09RD003"
col_data <- "Water.Temp.C"

# Data ----
df <- read.csv("DATA_QC_09RD003_AW_20170508_20201012.csv")
#
dim(df)
names(df)
str(df)

# Munge ----
## Add depth
df[, "depth_m"] <- 0.5
## Convert date time to POSIXct
df[, "Date.Time"] <- as.POSIXct(df[, "Date.Time"])
# str(df)


# Run Function ----
loggerdata <- df
datetimefield <- "Date.Time"
depthsfield <- "depth_m"
datafield <- col_data
analysistype <- "single"
#

ThreshAnalysis <- qcthresholdanalysis(loggerdata
                                      , datetimefield
                                      , depthsfield
                                      , datafield
                                      , analysistype)

# save results ----
fn_out <- paste0("ThresholdAnalsysis_Results_", SiteID, "_", col_data, ".xlsx")
# readme table
df_readme <- data.frame(matrix(NA, nrow = 11, ncol = 2))
df_readme[1, 1] <- toupper("Project Name:")
df_readme[1, 2] <- "ContDataQC, Tim's QC Threshold Analysis"
df_readme[2, 1] <- toupper("Project Description:")
df_readme[2, 2] <- "Test Tim's function with some data"
df_readme[4, 1] <- toupper("File:")
df_readme[4, 2] <- fn_out
df_readme[5, 1] <- toupper("Created:")
df_readme[5, 2] <- as.character(Sys.time())
df_readme[6, 1] <- toupper("Full Path:")
df_readme[6, 2] <- "=LEFT(@CELL(\"filename\",B9),FIND(\"]\",@CELL(\"filename\",B9)))"
df_readme[7, 1] <- toupper("Worksheet:")
df_readme[7, 2] <- "=MID(@CELL(\"filename\",B10),FIND(\"]\",@CELL(\"filename\",
B10))+1,LEN(@CELL(\"filename\",B10))-FIND(\"]\",@CELL(\"filename\",B10)))"
df_readme[9, 1] <- toupper("Sheet")
df_readme[9, 2] <- toupper("Description")
df_readme[9, 3] <- toupper("Link")
df_readme[10, 1] <- "gross"
df_readme[10, 2] <- "QC Check, Gross"
df_readme[10, 3] <- "=HYPERLINK(\"[\"&$B$7&\"]\"&A11&\"!A1\",A11)"
df_readme[11, 1] <- "spike"
df_readme[11, 2] <- "QC Check, Spike"
df_readme[11, 3] <- "=HYPERLINK(\"[\"&$B$7&\"]\"&A12&\"!A1\",A12)"
df_readme[12, 1] <- "roc"
df_readme[12, 2] <- "QC Check, Rate of Change (ROC)"
df_readme[12, 3] <- "=HYPERLINK(\"[\"&$B$7&\"]\"&A13&\"!A1\",A13)"
df_readme[13, 1] <- "flat"
df_readme[13, 2] <- "QC Check, Flat"
df_readme[13, 3] <- "=HYPERLINK(\"[\"&$B$7&\"]\"&A14&\"!A1\",A14)"
# write
write_xlsx(list("_readme" = df_readme
                , "gross" = ThreshAnalysis$gross
                , "spike" = ThreshAnalysis$spike
                , "roc" = ThreshAnalysis$roc
                , "flat" = ThreshAnalysis$flat)
           , path = fn_out
           , col_names = TRUE
           , format_headers = TRUE)
